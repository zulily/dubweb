#!/usr/bin/python
"""
    This script will generate an optional urls file, containing
    10 urls not present in the std_urls.json file that have the
    most visits per the bigquery table. Assumes user has creds.

    python gen_opt_urls.py -f ./std_urls.json

   Copyright 2017 zulily, Inc.

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
"""

from datetime import datetime
import os
import sys
import json
import argparse
import logging
from google.cloud import bigquery


OUTFILENAME = 'opt_urls.json'

def get_visited_urls(start_date):
    """
    Get visited urls from bigquery table
    """
    bq_client = bigquery.Client(project='your-google-projectid')
    parms = """ \
    SELECT count(1) cnt, origin, REGEXP_EXTRACT(page,r'(.*)\?')
    AS lp FROM [your-google-projectid:example:bqtable]
    where platform in ('foo', 'bar')
    and origin in ('foobar')
    and lp is not null
    and lp like ('https%')
    and process_time > '"""
    #'2017-01-01 00:00:00'
    suffix = """' group by origin, lp order by cnt desc limit 20;  """
    query_parms = parms + start_date.strftime('%Y-%m-%d %H:%M:%S') + suffix
    queryjob = bq_client.run_sync_query(query=query_parms)
    queryjob.run()
    try:
        results = queryjob.fetch_data(timeout_ms=30000)
    except ValueError:
        print "Query not complete before timeout."
    return results[0]


def load_json_file(filename):
    """
    Load std_urls file (json).
    """
    try:
        with open(filename, 'r') as urlfile:
            mydict = json.load(urlfile)
    except IOError:
        mydict = ""
        print " Couldn't load " + filename + "\n"
    return mydict


def write_json_file(filename, urllist):
    """
    Write opt_urls file (json).
    """
    try:
        with open(filename, 'w') as urlfile:
            json.dump(urllist, urlfile)
    except IOError:
        print " Couldn't write to " + filename + "\n"


def parse_arguments():
    """
    Collect command-line arguments
    """
    my_parser = argparse.ArgumentParser(description='Create opt urls for pagespeed.')
    my_parser.add_argument('-f', dest='filename',
                           help='path to json file with standard rules',
                           required=True)
    my_parser.add_argument('--verbose', '-v', dest='verbose',
                           action='store_true', help='enable verbose messages')
    return my_parser

def configure_logging(args):
    """
    Logging to console
    """
    format_string = '%(levelname)s:%(name)s:line %(lineno)s:%(message)s'
    log_format = logging.Formatter(format_string)
    log_level = logging.INFO if args.verbose else logging.WARN
    log_level = logging.DEBUG if args.debug else log_level
    console = logging.StreamHandler()
    console.setFormatter(log_format)
    console.setLevel(log_level)
    root_logger = logging.getLogger()
    if len(root_logger.handlers) == 0:
        root_logger.addHandler(console)
    root_logger.setLevel(log_level)
    root_logger.handlers[0].setFormatter(log_format)
    return logging.getLogger(__name__)


# Main functionality

def main():
    """
    Main function for url processing
    """

    urls = []
    new_urls = []
    args = parse_arguments().parse_args()
    logger = configure_logging(args)

    # Change to metrics directory containing definition file
    os.chdir(os.path.dirname(args.filename))
    filename = os.path.basename(args.filename)

    urls = load_json_file(filename)

    curtime = datetime.now()
    startdate = curtime.replace(day=1, hour=0, minute=0, second=0, microsecond=0)

    # load urls
    latest_urls = get_visited_urls(startdate)

    # Iterate through metric lines:
    for urlrow in latest_urls:
        url = str(urlrow[2])
        if url != 'None':
            if url not in urls and url.rstrip('/') not in urls:
                new_urls.append(url)

    write_json_file(OUTFILENAME, new_urls)

if __name__ == '__main__':
    sys.exit(main())

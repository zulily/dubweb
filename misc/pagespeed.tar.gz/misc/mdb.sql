-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema exampledb
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema exampledb
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `exampledb` DEFAULT CHARACTER SET latin1 ;
USE `exampledb` ;

-- -----------------------------------------------------
-- Table `exampledb`.`mtypes`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `exampledb`.`mtypes` (
  `mtid` MEDIUMINT(4) UNSIGNED NOT NULL AUTO_INCREMENT,
  `mtname` VARCHAR(64) NOT NULL,
  PRIMARY KEY (`mtid`),
  UNIQUE INDEX `mtid_UNIQUE` (`mtid` ASC),
  INDEX `mtname_UNIQUE` (`mtname` ASC))
ENGINE = InnoDB
AUTO_INCREMENT = 1
DEFAULT CHARACTER SET = latin1;

-- -----------------------------------------------------
-- Table `exampledb`.`murls`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `exampledb`.`murls` (
  `muid` MEDIUMINT(4) UNSIGNED NOT NULL AUTO_INCREMENT,
  `murl` VARCHAR(720) NOT NULL,
  PRIMARY KEY (`muid`),
  UNIQUE INDEX `muid_UNIQUE` (`muid` ASC),
  INDEX `murl_UNIQUE` (`murl` ASC))
ENGINE = InnoDB
AUTO_INCREMENT = 1
DEFAULT CHARACTER SET = latin1;

-- -----------------------------------------------------
-- Table `exampledb`.`mrule`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `exampledb`.`mrule` (
  `mrid` MEDIUMINT(4) UNSIGNED NOT NULL AUTO_INCREMENT,
  `mrule` VARCHAR(720) NOT NULL,
  PRIMARY KEY (`mrid`),
  UNIQUE INDEX `mrid_UNIQUE` (`mrid` ASC),
  INDEX `mrule_UNIQUE` (`mrule` ASC))
ENGINE = InnoDB
AUTO_INCREMENT = 1
DEFAULT CHARACTER SET = latin1;

-- -----------------------------------------------------
-- Table `exampledb`.`mruleset`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `exampledb`.`mruleset` (
  `mrsid` MEDIUMINT(4) UNSIGNED NOT NULL AUTO_INCREMENT,
  `mrsdate` DATETIME NOT NULL,
  `mdid` INT(8) UNSIGNED NOT NULL,
  `mrid` MEDIUMINT(4) UNSIGNED NOT NULL,
  `mimpact` FLOAT NOT NULL,
  PRIMARY KEY (`mrsid`),
  UNIQUE INDEX `mrsid_UNIQUE` (`mrsid` ASC),
  INDEX `IDX_mrs_mdid` (`mdid` ASC),
  INDEX `IDX_mrs_date` (`mrsdate` ASC),
  CONSTRAINT `mrs_mrid`
    FOREIGN KEY (`mrid`)
    REFERENCES `exampledb`.`mrule` (`mrid`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `mrs_mdid`
    FOREIGN KEY (`mdid`)
    REFERENCES `exampledb`.`mdata` (`mdid`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 1
DEFAULT CHARACTER SET = latin1;

-- -----------------------------------------------------
-- Table `exampledb`.`mfailure`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `exampledb`.`mfailure` (
  `mfid` MEDIUMINT(4) UNSIGNED NOT NULL AUTO_INCREMENT,
  `mfailure` VARCHAR(720) NOT NULL,
  PRIMARY KEY (`mfid`),
  UNIQUE INDEX `mfid_UNIQUE` (`mfid` ASC),
  INDEX `mfailure_UNIQUE` (`mfailure` ASC))
ENGINE = InnoDB
AUTO_INCREMENT = 1
DEFAULT CHARACTER SET = latin1;

-- -----------------------------------------------------
-- Table `exampledb`.`mfailureset`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `exampledb`.`mfailureset` (
  `mfsid` MEDIUMINT(4) UNSIGNED NOT NULL AUTO_INCREMENT,
  `mrsid` MEDIUMINT(4) UNSIGNED NOT NULL,
  `mdid` INT(8) UNSIGNED NOT NULL,
  `mfid` MEDIUMINT(4) UNSIGNED NOT NULL,
  PRIMARY KEY (`mfsid`),
  UNIQUE INDEX `mfsid_UNIQUE` (`mfsid` ASC),
  INDEX `IDX_mfs_mrsid` (`mrsid` ASC),
  CONSTRAINT `mfs_mrsid`
    FOREIGN KEY (`mrsid`)
    REFERENCES `exampledb`.`mruleset` (`mrsid`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `mfs_mdid`
    FOREIGN KEY (`mdid`)
    REFERENCES `exampledb`.`mdata` (`mdid`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 1
DEFAULT CHARACTER SET = latin1;

-- -----------------------------------------------------
-- Table `exampledb`.`mdata`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `exampledb`.`mdata` (
  `mdid` INT(8) UNSIGNED NOT NULL AUTO_INCREMENT,
  `mdate` DATETIME NOT NULL,
  `mtid` MEDIUMINT(4) UNSIGNED NOT NULL,
  `muid` MEDIUMINT(4) UNSIGNED NOT NULL,
  `mdata` FLOAT SIGNED NOT NULL,
  PRIMARY KEY (`mdid`),
  UNIQUE INDEX `mdid_UNIQUE` (`mdid` ASC),
  INDEX `IDX_Datetime` (`mdate` ASC),
  CONSTRAINT `md_mtid`
    FOREIGN KEY (`mtid`)
    REFERENCES `exampledb`.`mtypes` (`mtid`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `md_muid`
    FOREIGN KEY (`muid`)
    REFERENCES `exampledb`.`murls` (`muid`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 1
DEFAULT CHARACTER SET = latin1;



SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;


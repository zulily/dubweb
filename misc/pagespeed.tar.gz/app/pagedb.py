#!/usr/bin/env python

import sys
from datetime import timedelta, datetime
import json
import urllib
from collections import defaultdict
import MySQLdb

DB_USER = 'readonly_username'
DB_URL = 'db_host_fqdn'
DB_PASS = 'password_for_readonly_hostname'
DB_DB = "exampledb"

dtformat = "%Y-%m-%d %H:%M:%S"


def get_current_data_pagespeed(js_start, js_end):

    datalist = []
    # number of metrics to collapse
    rangeinc = 3

    pagespeed_query = """
        SELECT md.mdate, mu.murl, mt.mtname, md.mdata
        FROM exampledb.mdata as md
        JOIN exampledb.mtypes as mt on md.mtid = mt.mtid
        JOIN exampledb.murls as mu on md.muid = mu.muid
        WHERE md.mdate between %s and %s
        ORDER by mu.murl ASC;
    """
    conn = open_monitoring_db()
    if js_start and js_end:
        startt = datetime.fromtimestamp(int(js_start)/1000)
        endt = datetime.fromtimestamp(int(js_end)/1000)
    else:
        endt = datetime.now()
        startt = endt - timedelta(hours=12)

    rawstats = get_from_db(conn, pagespeed_query, (startt, endt))
    for i in range(0, len(rawstats), rangeinc):
        row = {}
        row["Date"] = str(rawstats[i][0])
        row["URL"] = rawstats[i][1]
        # Combine i metrics for dashboard affect
        for j in range(0, rangeinc):
            if rawstats[i][1] == rawstats[i+j][1]:
                row[rawstats[i+j][2]] = rawstats[i+j][3]
            else:
                row[rawstats[i+j][2]] = -1
        datalist.append(row)
    return json.dumps(datalist)

def get_weeks_data_pagespeed(js_start, js_end, url_enc):

    datalist = []
    queryparms = []

    pagespeed_query = """
        SELECT UNIX_TIMESTAMP(md.mdate) as ts, mu.murl, mt.mtname, md.mdata
        FROM exampledb.mdata as md
        JOIN exampledb.mtypes as mt on md.mtid = mt.mtid
        JOIN exampledb.murls as mu on md.muid = mu.muid
        WHERE md.mdate between %s and %s
    """
    query_suffix = " ORDER by mu.murl, ts ASC;"
    conn = open_monitoring_db()
    if js_start and js_end:
        startt = datetime.fromtimestamp(int(js_start)/1000)
        endt = datetime.fromtimestamp(int(js_end)/1000)
    else:
        endt = datetime.now()
        startt = endt - timedelta(days=14)

    queryparms.extend([startt, endt])
    if url_enc:
        url = urllib.unquote_plus(url_enc)
        pagespeed_query += " AND mu.murl = %s "
        queryparms.append(str(url))

    pagespeed_query += query_suffix

    rawstats = get_from_db(conn, pagespeed_query, tuple(queryparms))
    i = 0
    while i < len(rawstats):
        row = {}
        row["Date"] = datetime.fromtimestamp(int(rawstats[i][0])).strftime('%Y-%m-%d %H:%M')
        row["URL"] = rawstats[i][1]
        chartvals = defaultdict(list)
        # add initial value url, formatting for chart
        chartvals[rawstats[i][2]].append([rawstats[i][0],
                                          rawstats[i][3]])
        j = i + 1
        # Combine metrics for url, formatting for chart
        while j < len(rawstats) and rawstats[i][1] == rawstats[j][1]:
            chartvals[rawstats[j][2]].append([rawstats[j][0],
                                              rawstats[j][3]])
            row["Date"] = datetime.fromtimestamp(int(rawstats[j][0])).strftime('%Y-%m-%d %H:%M')
            j = j + 1
        row["data"] = chartvals
        datalist.append(row)
        i = j

    return json.dumps(sorted(datalist, reverse=True))

def get_pagespeed_rules(url_enc, ts, metric):

    retdict = {}
    datalist = []
    queryparms = []
    rawstats = []

    rule_query = """
        SELECT UNIX_TIMESTAMP(mrs.mrsdate) as ts, mr.mrule, mrs.mimpact,
        mf.mfailure FROM exampledb.mruleset as mrs
        JOIN exampledb.mdata as md on mrs.mdid = md.mdid
        JOIN exampledb.murls as mu on md.muid = mu.muid
        JOIN exampledb.mtypes as mt on md.mtid = mt.mtid
        JOIN exampledb.mrule as mr on mrs.mrid = mr.mrid
        JOIN exampledb.mfailureset as mfs on mrs.mrsid = mfs.mrsid
        JOIN exampledb.mfailure as mf on mfs.mfid = mf.mfid
        WHERE 1
    """
    conn = open_monitoring_db()
    url = urllib.unquote_plus(url_enc)
    if url and ts and metric:
        rule_query += " AND mu.murl = %s "
        queryparms.append(str(url))
        rule_query += " AND mrs.mrsdate = FROM_UNIXTIME(%s) "
        queryparms.append(ts)
        rule_query += " AND mt.mtname = %s "
        queryparms.append(str(metric))
        rule_query += " ORDER by mrs.mimpact DESC;"
        rawstats = get_from_db(conn, rule_query, tuple(queryparms))

        retdict['URL'] = url
        retdict['metric'] = metric

        i = 0
        while i < len(rawstats):
            row = {}
            row["Date"] = rawstats[i][0]
            row["Rule"] = rawstats[i][1]
            row["Impact"] = rawstats[i][2]
            failures = []
            # add initial value url, formatting for chart
            failures.append(rawstats[i][3])
            j = i + 1
            # Combine metrics for url, formatting for chart
            while j < len(rawstats) and rawstats[i][1] == rawstats[j][1]:
                failures.append(rawstats[j][3])
                j = j + 1
            row["Values"] = failures
            datalist.append(row)
            i = j
        retdict['data'] = datalist
        return json.dumps(retdict)

    return None

def open_monitoring_db():
    """
    Open MySQL monitoring DB
    """
    try:
        conn = MySQLdb.connect(host=DB_URL,
                               user=DB_USER,
                               passwd=DB_PASS,
                               db=DB_DB)

    except Exception, err:
        print"mysql exception: %s"  % err
        sys.exit(1)

    return conn


def get_from_db(conn, query, query_params):
    """
    Given a query and optional parameters...
    Return the results
    """

    dblist = []

    cursor = conn.cursor()
    try:
        if query_params:
            cursor.execute(query, query_params)
        else:
            cursor.execute(query)
        dblist = cursor.fetchall()
    except Exception, err:
        print "mysql exception: %s from %s" % (err, query)
    finally:
        cursor.close()

    return dblist

def transform_data_for_n3(ddict):
    retlist = []
    for kkey in ddict.keys():
        retlist.append({"key": kkey, "values":ddict[kkey]})

    return retlist


if __name__ == "__main__":

    """
    test1=True

    if test1:
        startt=time.mktime(dt.datetime(2015, 3, 20, 5, 45).timetuple())
        endt=time.mktime(dt.datetime(2015, 3, 20, 8, 45).timetuple())
        print get_data_for_web(startt * 1000, endt * 1000)
    else:
        startt=dt.datetime(2015, 3, 20, 5, 45)
        endt=dt.datetime(2015, 3, 20, 8, 45)

    for k in req_dict:
        data=process_from_db(req_dict[k]["dict"], req_dict[k]["query"], startt.strftime(dtformat), endt.strftime(dtformat))
        x=transform_data_for_n3(data)
        with open(req_dict[k]['out'], 'w') as outfile:
            json.dump(x, outfile)

    cpu = json.load(open("cpu.json"))
    reqs = json.load(open("reqs.json"))
    transform_data_for_n3(get_magic_numbers(cpu, reqs))

  """


    print get_weeks_data_pagespeed(None, None, None)
    #print get_pagespeed_rules('https://www.google.com/', 1484244000, 'Desktop SPEED')


import logging
from logging.handlers import RotatingFileHandler
from flask import Flask, request
import pagedb


app = Flask(__name__)
@app.route("/")
def usage():
    return "Usage message"

@app.route('/pagespeed/current/')
def pages_get_current():
  date = request.args.get('Date')
  url = request.args.get('Url')
  metric = request.args.get('Metric')
  score = request.args.get('Score')
  return pagedb.get_current_data_pagespeed(None, None)

@app.route('/pagespeed/weekly/')
def pages_get_weekly():
  start = request.args.get('start')
  end = request.args.get('end')
  url = request.args.get('url')
  return pagedb.get_weeks_data_pagespeed(None, None, url)

@app.route('/pagespeed/rules/')
def pages_get_rules():
  url = request.args.get('url')
  ts = request.args.get('ts')
  metric = request.args.get('metric')
  return pagedb.get_pagespeed_rules(url, ts, metric)

if __name__ == "__main__":
    formatter = logging.Formatter(
      "[%(asctime)s] {%(pathname)s:%(lineno)d} %(levelname)s - %(message)s")
    handler = RotatingFileHandler('/tmp/foo.log', maxBytes=100000000, backupCount=5)
    handler.setLevel(logging.INFO)
    app.logger.addHandler(handler)
    app.run()

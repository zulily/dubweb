#!/usr/bin/python
"""
    This script will extract metrics from a source, based on the rules
    contained in the driver file in the definitions subdirectory,
    (provided by the -f parameter), and calculate a set of capacity
    models based on the time supplied in the rules.

    Optionally,
    add -d to the command line in order to debug (no estimate writes).
    Add -v to the command line for verbose output from imported modules.
    Add -e to the command line for estimation only (no model recalculation).

    python cap_model_recalc.py -d -f ./definitions/cap_master.json

   Copyright 2015 zulily, Inc.

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
"""

import MySQLdb
import os
import sys
import json
import argparse
import logging
import pprint
import datetime
import numpy as np
from collections import OrderedDict

OUTLIER_PCT = .2
MISSING_PCT = .05


class CapCalc(object):
    """
        Class for each metric set (e.g., a day of datacenter foo's metrics,
        or a month of datacenter bar's metrics).  Includes separate instance
        of projects teams, as each set can add projects.
    """

    def __init__(self, cap_def, captype_id, current_date,
                 metric_defs, c_conn, m_conn, c_logger, estimate_only):
        """
        Initialize the object, processing the data for the file,
        calculating a capacity model if necessary
        """

        self.current_stats = OrderedDict()
        self.metrics = OrderedDict()
        self.periods = []
        self.logger = c_logger
        self._capid = captype_id
        self._cconn = c_conn
        self._mconn = m_conn
        self._current_date = current_date
        self._captype = cap_def[0]
        self._metric_source = cap_def[2]
        self._metric_period = cap_def[3]
        if not estimate_only:
            self._metric_date = self._get_perf_metric_max_days()
            metrics = self._get_perf_metric_sums()
            self._sanitize_metrics(metrics)
            self._generate_model(metric_defs)


    def _generate_model(self, metric_list):
        """
        Given a set of metrics, calculate the model & coeff
        capacity for the given metrics provider.
        """
        # Determine normalization coefficient
        dstat = {}
        coef = float(max(min(self.metrics.values()[0]), 1))

        #Extract driver metric values
        for dmetric in metric_list["source"]:
            dstat[dmetric[0]] = self._get_driver_metric(dmetric,
                                                        self._metric_date)
            logging.debug(pprint.pformat(dstat))

            #calculate pattern
            for mhr in range(0, len(self.metrics[self._metric_date])):
                self.current_stats[self.periods[mhr]] = \
                    self.metrics[self._metric_date][mhr] \
                    / coef / dstat[dmetric[0]]

        #update capacity model
        if not self.logger.isEnabledFor(logging.DEBUG):
            self._update_model(coef)


    def _get_driver_metric(self, source_metric, my_date):
        """
        Get daily external metric that drives
        the daily metric being calculated
        """
        cursor = self._mconn.cursor()
        logging.debug(pprint.pformat(my_date))

        query = """
                SELECT CAST(max(pd.data) AS SIGNED) AS metric_total
                FROM perfdata pd
                JOIN perftypes pt ON pt.metricid = pd.metric
                WHERE pt.metricname = %s
             """
        query += source_metric[1]
        try:

            cursor.execute(query, (source_metric[0], my_date))
            drivermetric = cursor.fetchall()
            logging.debug(pprint.pformat(drivermetric))

        except MySQLdb.Error, err:
            print "Error %d: %s" % (err.args[0], err.args[1])
            sys.exit(1)

        cursor.close()
        return drivermetric[0][0]

    def _get_perf_metric_max_days(self):
        """
        Get top 5 days of the internal service metric
        being modeled for capacity
        """
        cursor = self._mconn.cursor()
        query = """
                SELECT DATE_FORMAT(pd.datetime,'%%Y-%%m-%%d 00:00:00')
                AS metric_date FROM perfdata pd
                JOIN perftypes pt ON pt.metricid = pd.metric
                WHERE pt.metricname = %s
                AND pd.datetime BETWEEN DATE_SUB(CURDATE(), INTERVAL 8 day)
                AND DATE_SUB(CURDATE(), INTERVAL 1 day)
                GROUP BY DATE_FORMAT(pd.datetime,'%%Y-%%m-%%d')
                ORDER BY sum(pd.data) DESC LIMIT 5;
             """
        try:
            cursor.execute(query, (self._metric_source,))
        except MySQLdb.Error, err:
            print "Error %d: %s" % (err.args[0], err.args[1])
            sys.exit(1)

        output = cursor.fetchall()

        cursor.close()
        return output[0]


    def _get_perf_metric_sums(self):
        """
        Get periodic sums of the given days' service metric
        being modeled for capacity
        """
        period_metrics = OrderedDict()
        cursor = self._mconn.cursor()
        qdate = "DATE_FORMAT(pd.datetime,'" + self._metric_period + "')"
        query_body = """
                , CAST(SUM(pd.data) AS SIGNED) AS metric_total
                FROM perfdata pd
                JOIN perftypes pt ON pt.metricid = pd.metric
                WHERE pt.metricname = %s
                AND pd.datetime BETWEEN %s
                AND DATE_ADD(%s, INTERVAL '23:59:59' HOUR_SECOND)
                GROUP BY """
        query = "SELECT "+ qdate + query_body + qdate + \
                " ORDER BY pd.datetime ASC;"
        try:
            periods = []
            for mdate in self._metric_date:
                cursor.execute(query, (self._metric_source, mdate, mdate))
                output = cursor.fetchall()
                vals = []
                for i in range(0, len(output)):
                    vals.append(output[i][1])
                    if not output[i][0] in self.periods:
                        periods.append(output[i][0])

                period_metrics[mdate] = vals

            self.periods = sorted(periods)
            #logging.debug(pprint.pformat(self.periods))

        except MySQLdb.Error, err:
            print "Error %d: %s" % (err.args[0], err.args[1])
            sys.exit(1)

        cursor.close()
        return period_metrics


    def _get_cap_coefs(self):
        """
        Get current capacity coefficients from MySQL capacity DB
        """
        coefs = {}
        cursor = self._cconn.cursor()
        query = """
                   SELECT constname, constval FROM capacity_constants
                   WHERE typeid = %s
                """

        try:
            cursor.execute(query, (self._capid,))
        except MySQLdb.Error, err:
            print "Error %d: %s" % (err.args[0], err.args[1])
            sys.exit(1)

        output = cursor.fetchall()
        for i in range(0, len(output)):
            coefs[output[i][0]] = output[i][1]
        cursor.close()
        return coefs


    def _get_cap_model_metrics(self):
        """
        Get current capacity model from MySQL capacity DB
        """
        metrics = OrderedDict()
        cursor = self._cconn.cursor()
        query = """
                   SELECT period, factor FROM capacity_patterns
                   WHERE typeid = %s
                   ORDER BY period ASC
                """
        try:
            cursor.execute(query, self._capid)
        except MySQLdb.Error, err:
            print "Error %d: %s" % (err.args[0], err.args[1])
            sys.exit(1)

        output = cursor.fetchall()
        for i in range(0, len(output)):
            metrics[output[i][0]] = output[i][1]
        cursor.close()
        return metrics


    def _sanitize_metrics(self, my_metrics):
        """
        Given the periodic sums of multiple days of the service metric,
        return the max day with < 20% occurrences of a period < median
        (which drops zeros, etc.)
        """
        periods = len(self.periods)
        for mydate in my_metrics.iterkeys():
            if len(my_metrics[mydate]) < periods - (periods * MISSING_PCT):
                logging.debug('Missing values. Dropping date of %s', mydate)
                del my_metrics[mydate]
        arr = np.array(my_metrics.values())
        mdn = np.median(arr, axis=0)
        for mydate in my_metrics.iterkeys():
            noncoms = 0
            self.metrics[mydate] = []
            for period in range(0, periods):
                value = my_metrics[mydate][period]
                self.metrics[mydate].append(value)
                if abs(value) < abs(mdn[period]):
                    try:
                        noncoms += 1
                    except KeyError:
                        noncoms = 1
            if noncoms <= OUTLIER_PCT * periods:
                self._metric_date = mydate
                return
            else:
                del self.metrics[mydate]

    def _update_captype_stats(self):
        """
        Update calculation time for capacity type in MySQL DB
        """
        cursor = self._cconn.cursor()
        query = "UPDATE capacity_types SET lastetl = %s WHERE typeid = %s"

        try:
            cursor.execute(query, (self._current_date, self._capid))
        except MySQLdb.Error, err:
            print "Error %d: %s" % (err.args[0], err.args[1])
            sys.exit(1)
        self._cconn.commit()
        cursor.close()

    def _update_model(self, c_coef):
        """
        Write capacity model and coef to the capacity db

        """
        cursor = self._cconn.cursor()
        query = """\
        INSERT INTO capacity_patterns
        (period, typeid, factor)
        VALUES (%s,%s,%s)
        ON DUPLICATE KEY UPDATE
        factor = %s;
        """
        for mperiod in self.current_stats.keys():
            value = self.current_stats[mperiod]
            try:
                cursor.execute(query, (mperiod, self._capid, value, value))
            except MySQLdb.Error, err:
                print "Error %d: %s" % (err.args[0], err.args[1])
                sys.exit(1)

        self._cconn.commit()
        query = """
        INSERT INTO capacity_constants
        (constname, typeid, constval)
        VALUES (%s,%s,%s)
        ON DUPLICATE KEY UPDATE
        constval = %s;
        """
        try:
            cursor.execute(query, (self._captype, self._capid, c_coef, c_coef))
        except MySQLdb.Error, err:
            print "Error %d: %s" % (err.args[0], err.args[1])
            sys.exit(1)
        self._cconn.commit()

        cursor.close()

    def calculate_periodic_estimates(self, metric_list):
        """
        Given a capacity model, calculate estimates
        for the given metrics provider.
        """
        self.current_stats = OrderedDict()
        dstat = {}
        coefs = self._get_cap_coefs()

        metrics = self._get_cap_model_metrics()
        #Extract driver metric values
        for dmetric in metric_list["estimates"]:
            dstat[dmetric[0]] = self._get_driver_metric(dmetric,
                                                        self._current_date)

            for period in metrics.keys():
                self.current_stats[period] = int(metrics[period] *\
                    coefs[self._captype] * dstat[dmetric[0]])


    def write_estimates(self):
        """
        Write current_stats to the capacity estimates table

        """
        cursor = self._cconn.cursor()
        query = """\
        INSERT INTO capacity_estimates
        (period, typeid, value)
        VALUES (%s,%s,%s)
        ON DUPLICATE KEY UPDATE
        value = %s;
        """

        for mperiod in self.current_stats.iterkeys():
            value = self.current_stats[mperiod]
            try:
                cursor.execute(query, (mperiod, self._capid, value, value))
            except MySQLdb.Error, err:
                print "Error %d: %s" % (err.args[0], err.args[1])
                sys.exit(1)

        self._cconn.commit()
        cursor.close()

        self._update_captype_stats()


def load_json_file(filename):
    """
    Load model file (json).
    """
    try:
        with open(filename, 'r') as historyfile:
            mydict = json.load(historyfile)
    except IOError:
        mydict = ""
        print " Couldn't load " + filename + "\n"
    return mydict

def open_db(dbhost, dbuser, dbpass, database):
    """
    Open MySQL DB
    """
    try:
        conn = MySQLdb.connect(host=dbhost, user=dbuser,
                               passwd=dbpass, db=database)

    except MySQLdb.Error, err:
        print "Error %d: %s" % (err.args[0], err.args[1])
        sys.exit(1)

    return conn

def get_captype_id(conn, cap_type, metric_id):
    """
    Get current capacity id from MySQL capacity DB,
    creating if it doesn't exist.
    """
    cursor = conn.cursor()
    insquery = """
               INSERT IGNORE INTO capacity_types 
               SET `typename` = %s, 
               `metricid` = %s;
               """
    selquery = """
               SELECT typeid FROM capacity_types WHERE typename = %s;
               """
    try:
        cursor.execute(insquery, (cap_type, metric_id))
        conn.commit()
        cursor.execute(selquery, cap_type)
    except MySQLdb.Error, err:
        print "Error %d: %s" % (err.args[0], err.args[1])
        sys.exit(1)

    output = cursor.fetchall()
    cursor.close()
    return int(output[0][0])

def get_metric_id(conn, metric_name):
    """
    Get current metric id from MySQL monitoring DB.
    """
    cursor = conn.cursor()
    selquery = """
               SELECT metricid FROM perftypes WHERE metricname = %s;
               """
    try:
        cursor.execute(selquery, metric_name)
    except MySQLdb.Error, err:
        print "Error %d: %s" % (err.args[0], err.args[1])
        sys.exit(1)

    output = cursor.fetchall()
    cursor.close()
    return int(output[0][0])

def parse_arguments():
    """
    Collect command-line arguments
    """
    my_parser = argparse.ArgumentParser(description='Calculate Models.')
    my_parser.add_argument('-f', dest='filename',
                           help='path to json file with model rules',
                           required=True)
    my_parser.add_argument('--verbose', '-v', dest='verbose',
                           action='store_true', help='enable verbose messages')
    my_parser.add_argument('--debug', '-d', dest='debug', action='store_true',
                           help='enable debug-only mode (no mysql writing)')
    my_parser.add_argument('--estimates_only', '-e', dest='estimate',
                           action='store_true', help='no model recalc.')
    return my_parser

def configure_logging(args):
    """
    Logging to console
    """
    format_string = '%(levelname)s:%(name)s:line %(lineno)s:%(message)s'
    log_format = logging.Formatter(format_string)
    log_level = logging.INFO if args.verbose else logging.WARN
    log_level = logging.DEBUG if args.debug else log_level
    console = logging.StreamHandler()
    console.setFormatter(log_format)
    console.setLevel(log_level)
    root_logger = logging.getLogger()
    if len(root_logger.handlers) == 0:
        root_logger.addHandler(console)
    root_logger.setLevel(log_level)
    root_logger.handlers[0].setFormatter(log_format)
    return logging.getLogger(__name__)


# Main functionality

def main():
    """
    Main function for model processing, may generate
    many models in one run
    """
    args = parse_arguments().parse_args()
    logger = configure_logging(args)

    # Change to directory containing definition file
    os.chdir(os.path.dirname(args.filename))
    filename = os.path.basename(args.filename)

    defs = load_json_file(filename)

    currenttime = datetime.datetime.now()

    if logger.isEnabledFor(logging.DEBUG):
        logging.debug('Calculate %s on %s', filename, currenttime.ctime())
        logging.debug(pprint.pformat(defs))

    # open capacity and metrics DBs
    cconn = open_db(defs["cdbhost"], defs["cdbuser"],
                    defs["cdbpass"], defs["cdatabase"])

    mconn = open_db(defs["mdbhost"], defs["mdbuser"],
                    defs["mdbpass"], defs["mdatabase"])

    # Iterate through capacity metrics, recalculating each
    for capdef in defs["metricstypes"]:
        captype = capdef[0]
        metricid = get_metric_id(mconn, capdef[2])
        captypeid = get_captype_id(cconn, captype, metricid)
        if captypeid < 1:
            #unknown capacity type
            continue
        capfilename = capdef[1]
        capmetricdefs = load_json_file(capfilename)
        if logger.isEnabledFor(logging.DEBUG):
            logging.debug('Got provider of %s', captype)
            logging.debug('Got stats file of %s', capfilename)
            logging.debug(pprint.pformat(capmetricdefs))

        # Create an instance for each capacity model
        cap_model = CapCalc(capdef, captypeid, currenttime, capmetricdefs,
                            cconn, mconn, logger, args.estimate)
        if logger.isEnabledFor(logging.DEBUG):
            logging.debug('Starting on capacity estimates')
        cap_model.calculate_periodic_estimates(capmetricdefs)
        if logger.isEnabledFor(logging.DEBUG):
            logging.debug('On %s, %s gave current_stats of:',
                          currenttime.ctime(), captype)
            logging.debug(pprint.pformat(cap_model.current_stats))
        elif len(cap_model.current_stats) > 0:
            cap_model.write_estimates()
        else:
            logging.error('Failed creating capacity estimates for %s', captype)

    # end capacity loop
    mconn.close()
    cconn.close()


if __name__ == '__main__':
    sys.exit(main())

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema scale_perf
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `scale_perf` ;
USE `scale_perf` ;


-- -----------------------------------------------------
-- Table `scale_perf`.`capacity_types`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `scale_perf`.`capacity_types` (
  `typeid` TINYINT(4) UNSIGNED NOT NULL AUTO_INCREMENT,
  `typename` VARCHAR(255) NOT NULL,
  `metricid` TINYINT(4) UNSIGNED NOT NULL,
  `lastetl` DATETIME,
  PRIMARY KEY (`typeid`),
  UNIQUE INDEX `typeid_UNIQUE` (`typeid` ASC))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `scale_perf`.`capacity_constants`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `scale_perf`.`capacity_constants` (
  `constid` TINYINT(4) UNSIGNED NOT NULL AUTO_INCREMENT,
  `constname` VARCHAR(255) NOT NULL,
  `typeid` TINYINT(4) UNSIGNED NOT NULL,
  `constval` DOUBLE(20,9) NOT NULL,
  PRIMARY KEY (`constid`),
  UNIQUE INDEX `constid_UNIQUE` (`constid` ASC),
  INDEX `typeid_index` (`typeid` ASC),
  CONSTRAINT `const_typeid`
    FOREIGN KEY (`typeid`)
    REFERENCES `scale_perf`.`capacity_types` (`typeid`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `scale_perf`.`capacity_patterns`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `scale_perf`.`capacity_patterns` (
  `id` SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `period` VARCHAR(48) NOT NULL,
  `typeid` TINYINT(4) UNSIGNED NOT NULL,
  `factor` DOUBLE(20,9) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `id_UNIQUE` (`id` ASC),
  INDEX `typeid_idx` (`typeid` ASC),
  CONSTRAINT `pat_typeid`
    FOREIGN KEY (`typeid`)
    REFERENCES `scale_perf`.`capacity_types` (`typeid`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `scale_perf`.`capacity_estimates`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `scale_perf`.`capacity_estimates` (
  `id` SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `period` VARCHAR(48) NOT NULL,
  `typeid` TINYINT(4) UNSIGNED NOT NULL,
  `value` INT(11) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `id_UNIQUE` (`id` ASC),
  INDEX `typeid_idx` (`typeid` ASC),
  CONSTRAINT `est_typeid`
    FOREIGN KEY (`typeid`)
    REFERENCES `scale_perf`.`capacity_types` (`typeid`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;

ALTER TABLE `scale_perf`.`capacity_types`
ADD CONSTRAINT type_UQ
UNIQUE (typename);

ALTER TABLE `scale_perf`.`capacity_patterns`
  ADD CONSTRAINT pat_UQ
    UNIQUE (period, typeid);

ALTER TABLE `scale_perf`.`capacity_estimates`
  ADD CONSTRAINT est_UQ
    UNIQUE (period, typeid);
    
ALTER TABLE `scale_perf`.`capacity_constants`
  ADD CONSTRAINT const_UQ
    UNIQUE (constname, typeid);    


INSERT INTO `scale_perf`.`capacity_types`
(`typename`, `metricid`)
VALUES
  ('foo', 66);
  
